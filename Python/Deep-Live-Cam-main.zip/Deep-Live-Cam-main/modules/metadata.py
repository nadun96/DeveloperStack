name = 'Deep Live Cam'
version = '1.6.0'
edition = 'Portable'
