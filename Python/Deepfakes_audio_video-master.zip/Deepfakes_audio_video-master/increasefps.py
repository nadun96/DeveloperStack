import cv2 

out = cv2.VideoWriter(str(videoname+"AV.avi"),cv2.VideoWriter_fourcc('X','V','I','D'),  fps, (fw,fh))